import { NeedsWantsAnalyzer } from "@/components/NeedsWantsAnalyzer";
import { SmartAdvisor } from "@/components/SmartAdvisor";
import { Wallet, Brain, TrendingUp } from "lucide-react";

const Index = () => {
  return (
    <div className="min-h-screen gradient-hero-bg">
      {/* Header */}
      <header className="border-b border-border/50 bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <div className="p-2 gradient-bg rounded-xl">
              <Wallet className="h-6 w-6 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-xl font-display font-bold text-foreground">FinanceAI</h1>
              <p className="text-xs text-muted-foreground">Smart Money Management</p>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-12 md:py-16">
        <div className="text-center max-w-2xl mx-auto mb-12 animate-fade-in">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 rounded-full text-sm font-medium text-primary mb-6">
            <Brain className="h-4 w-4" />
            AI-Powered Finance Tools
          </div>
          <h2 className="text-4xl md:text-5xl font-display font-bold text-foreground mb-4">
            Take Control of Your{" "}
            <span className="gradient-text">Financial Future</span>
          </h2>
          <p className="text-lg text-muted-foreground">
            Use artificial intelligence to analyze your spending habits and get personalized advice to grow your wealth.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {[
            {
              icon: TrendingUp,
              title: "Smart Analysis",
              description: "AI categorizes your expenses instantly",
            },
            {
              icon: Brain,
              title: "Personalized Advice",
              description: "Get tailored financial recommendations",
            },
            {
              icon: Wallet,
              title: "Better Decisions",
              description: "Understand needs vs wants clearly",
            },
          ].map((feature, index) => (
            <div
              key={index}
              className="glass-card p-6 text-center animate-slide-up"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="inline-flex p-3 gradient-bg rounded-xl mb-4">
                <feature.icon className="h-6 w-6 text-primary-foreground" />
              </div>
              <h3 className="font-display font-semibold text-foreground mb-2">
                {feature.title}
              </h3>
              <p className="text-sm text-muted-foreground">{feature.description}</p>
            </div>
          ))}
        </div>

        {/* Main Tools */}
        <div className="grid lg:grid-cols-2 gap-8">
          <div className="animate-slide-up" style={{ animationDelay: "200ms" }}>
            <NeedsWantsAnalyzer />
          </div>
          <div className="animate-slide-up" style={{ animationDelay: "300ms" }}>
            <SmartAdvisor />
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/50 bg-card/30 mt-16">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center">
            <p className="text-sm text-muted-foreground">
              Powered by AI • Making smart financial decisions easier
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
