import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Loader2, ShoppingBag, Heart, Lightbulb, TrendingUp, DollarSign } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface AnalysisResult {
  category: "Need" | "Want" | "Unknown";
  confidence: number;
  reasoning: string;
  tips?: string[];
}

export function NeedsWantsAnalyzer() {
  const [expense, setExpense] = useState("");
  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);

  const analyzeExpense = async () => {
    if (!expense || !amount) {
      toast.error("Please enter an expense name and amount");
      return;
    }

    setLoading(true);
    setResult(null);

    try {
      const { data, error } = await supabase.functions.invoke("analyze-expense", {
        body: { expense, amount: parseFloat(amount), description },
      });

      if (error) throw error;

      setResult(data);
      toast.success("Analysis complete!");
    } catch (error: any) {
      console.error("Analysis error:", error);
      toast.error(error.message || "Failed to analyze expense");
    } finally {
      setLoading(false);
    }
  };

  const clearForm = () => {
    setExpense("");
    setAmount("");
    setDescription("");
    setResult(null);
  };

  return (
    <Card className="glass-card overflow-hidden">
      <CardHeader className="gradient-bg text-primary-foreground pb-8">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-primary-foreground/20 rounded-lg">
            <ShoppingBag className="h-6 w-6" />
          </div>
          <div>
            <CardTitle className="text-2xl font-display">Needs vs Wants Analyzer</CardTitle>
            <CardDescription className="text-primary-foreground/80">
              AI-powered expense categorization
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="p-6 space-y-6">
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">What did you buy?</label>
            <Input
              placeholder="e.g., New headphones, Groceries, Netflix subscription"
              value={expense}
              onChange={(e) => setExpense(e.target.value)}
              className="bg-secondary/50 border-border/50 focus:border-primary"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Amount ($)</label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                type="number"
                placeholder="0.00"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="pl-10 bg-secondary/50 border-border/50 focus:border-primary"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Additional context (optional)</label>
            <Textarea
              placeholder="Any extra details about this purchase..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="bg-secondary/50 border-border/50 focus:border-primary resize-none"
              rows={2}
            />
          </div>

          <div className="flex gap-3">
            <Button
              onClick={analyzeExpense}
              disabled={loading || !expense || !amount}
              className="flex-1 gradient-bg hover:opacity-90 transition-opacity"
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <TrendingUp className="mr-2 h-4 w-4" />
                  Analyze Expense
                </>
              )}
            </Button>
            {result && (
              <Button variant="outline" onClick={clearForm}>
                Clear
              </Button>
            )}
          </div>
        </div>

        {result && (
          <div className="animate-slide-up space-y-4 pt-4 border-t border-border/50">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div
                  className={`p-3 rounded-xl ${
                    result.category === "Need"
                      ? "bg-need/10 text-need"
                      : result.category === "Want"
                      ? "bg-want/10 text-want"
                      : "bg-muted text-muted-foreground"
                  }`}
                >
                  {result.category === "Need" ? (
                    <ShoppingBag className="h-6 w-6" />
                  ) : (
                    <Heart className="h-6 w-6" />
                  )}
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">This is a</p>
                  <p className="text-2xl font-display font-bold">{result.category}</p>
                </div>
              </div>
              <Badge
                variant="secondary"
                className={`text-sm px-3 py-1 ${
                  result.confidence >= 80
                    ? "bg-need/10 text-need"
                    : result.confidence >= 60
                    ? "bg-want/10 text-want"
                    : "bg-muted text-muted-foreground"
                }`}
              >
                {result.confidence}% confident
              </Badge>
            </div>

            <div className="p-4 bg-secondary/30 rounded-lg">
              <p className="text-sm text-foreground leading-relaxed">{result.reasoning}</p>
            </div>

            {result.tips && result.tips.length > 0 && (
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                  <Lightbulb className="h-4 w-4 text-want" />
                  Money-saving tips
                </div>
                <ul className="space-y-2">
                  {result.tips.map((tip, index) => (
                    <li
                      key={index}
                      className="flex items-start gap-2 text-sm text-foreground p-3 bg-want/5 rounded-lg"
                    >
                      <span className="text-want font-medium">•</span>
                      {tip}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
